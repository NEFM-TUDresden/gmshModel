"""Version information for GmshModel"""
# versioning scheme: major, minor, patch
versionInfo= 1, 0, 21

__version__= ".".join(map(str, versionInfo))
