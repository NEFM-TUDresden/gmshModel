"""Version information for GmshModel"""
# versioning scheme: major, minor, patch
versionInfo= 1, 1, 0

__version__= ".".join(map(str, versionInfo))
