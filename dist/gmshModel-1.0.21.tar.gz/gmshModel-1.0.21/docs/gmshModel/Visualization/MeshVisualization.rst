MeshVisualization
=================
The MeshVisualization provides the class definition for the mesh visualization of a Gmsh
model. It is based on the pyvista and vtk libraries und implements additional
features for the mesh visualization.


Class Definition
----------------

.. autoclass:: gmshModel.Visualization.MeshVisualization.MeshVisualization
   :show-inheritance:
   :members:



