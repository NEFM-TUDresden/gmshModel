GeometryVisualization
=====================
The GeometryVisualization provides the class definition for the geometry 
visualization of the model. It is based on the pythonocc library and provides 
simple methods for the visualization.


Class Definition
----------------

.. autoclass:: gmshModel.Visualization.GeometryVisualization.GeometryVisualization
   :show-inheritance:
   :members:

