DistanceCalculations
====================
This file provides methods for distance calculations


Methods
-------

.. automodule:: gmshModel.Geometry.DistanceCalculations
   :members:

